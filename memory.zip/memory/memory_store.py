import sqlite3
import json
from datetime import datetime

DB_NAME = "shared_memory.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS memory_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT,
            format TEXT,
            intent TEXT,
            timestamp TEXT,
            thread_id TEXT,
            extracted_values TEXT
        )
    ''')
    conn.commit()
    conn.close()

def log_entry(source, format_, intent, thread_id, extracted_values):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    timestamp = datetime.now().isoformat()
    cursor.execute('''
        INSERT INTO memory_log (source, format, intent, timestamp, thread_id, extracted_values)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (source, format_, intent, timestamp, thread_id, json.dumps(extracted_values)))
    conn.commit()
    conn.close()

def get_logs():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM memory_log')
    rows = cursor.fetchall()
    conn.close()
    return rows

# Run once to initialize DB
if __name__ == "__main__":
    init_db()
    print("Memory DB initialized.")
