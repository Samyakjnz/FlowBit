from memory.memory_store import log_entry
import uuid
from datetime import datetime

def transform_json(payload):
    required_fields = ["client_name", "rfq_number", "items", "deadline"]
    missing = [field for field in required_fields if field not in payload]

    if missing:
        return {"error": f"Missing fields: {', '.join(missing)}"}

    transformed = {
        "name": payload["client_name"],
        "reference": payload["rfq_number"],
        "line_items": payload["items"],
        "due_date": payload["deadline"]
    }

    # Log the transformation
    thread_id = str(uuid.uuid4())
    log_entry(
        source=payload["client_name"],
        format_="JSON",
        intent="RFQ",
        thread_id=thread_id,
        extracted_values=transformed
    )

    return transformed
