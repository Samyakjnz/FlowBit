import os
import json
from memory.memory_store import log_entry
import uuid

def detect_format(input_data):
    if isinstance(input_data, dict):
        return "JSON"
    elif isinstance(input_data, str):
        if input_data.strip().endswith(".pdf"):
            return "PDF"
        elif "Subject:" in input_data or "From:" in input_data:
            return "Email"
    return "Unknown"

def detect_intent(content):
    content_lower = content.lower()
    if "invoice" in content_lower:
        return "Invoice"
    elif "request for quote" in content_lower or "rfq" in content_lower:
        return "RFQ"
    elif "complaint" in content_lower:
        return "Complaint"
    elif "regulation" in content_lower or "compliance" in content_lower:
        return "Regulation"
    return "Unknown"

def classify_and_route(input_data, source_name):
    format_detected = detect_format(input_data)
    
    # Convert to string content for intent check
    if isinstance(input_data, dict):
        content = json.dumps(input_data)
    else:
        if os.path.isfile(input_data):
            with open(input_data, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        else:
            content = input_data

    intent = detect_intent(content)
    
    # Simulate thread ID generation
    thread_id = str(uuid.uuid4())

    # Log in memory
    extracted = {
        "source_file": source_name,
        "summary": content[:100]  # just the first 100 chars for demo
    }

    log_entry(source=source_name, format_=format_detected, intent=intent, thread_id=thread_id, extracted_values=extracted)

    print(f"Classified as: {format_detected} + {intent}")
    print(f"Thread ID: {thread_id}")
    return format_detected, intent, thread_id, content
