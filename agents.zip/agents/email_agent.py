import re
from memory.memory_store import log_entry
import uuid
from datetime import datetime

def extract_email_fields(email_content):
    sender = re.search(r"From:\s*(.*)", email_content)
    subject = re.search(r"Subject:\s*(.*)", email_content)

    sender_email = sender.group(1).strip() if sender else "Unknown"
    subject_text = subject.group(1).strip() if subject else "No Subject"

    # Basic urgency detection
    urgency_keywords = ["urgent", "asap", "immediately", "important", "high priority"]
    urgency = any(word in email_content.lower() for word in urgency_keywords)

    # Simulate intent again (simple)
    if "quote" in email_content.lower() or "rfq" in email_content.lower():
        intent = "RFQ"
    elif "invoice" in email_content.lower():
        intent = "Invoice"
    elif "complaint" in email_content.lower():
        intent = "Complaint"
    else:
        intent = "General Inquiry"

    # Simulated thread ID
    thread_id = str(uuid.uuid4())

    extracted = {
        "sender": sender_email,
        "subject": subject_text,
        "urgency": "High" if urgency else "Normal",
        "intent": intent,
        "received_at": datetime.now().isoformat()
    }

    log_entry(
        source=sender_email,
        format_="Email",
        intent=intent,
        thread_id=thread_id,
        extracted_values=extracted
    )

    return extracted
